$.i18n().load({
    "sr": {
        "regex_title": "Регуларни израз",
        "flag_title": "Опције",
        "text_title": "Тест текст",
        "button_text": "Прикажи решење",
        "button_test" : "Упореди решење",
        "correct": "Тачно",
        "incorrect" : "Нетачно",
    }
})