$.i18n().load({
    "en": {
        "msg_dragndrop_correct_answer": "You are correct!",
        "msg_dragndrop_incorrect_answer": "Incorret. You got $1 correct and $2 incorrect out of $3. You left $4 blank.",
        "msg_dragndrop_check_me": "Check me",
        "msg_dragndrop_reset": "Reset"
    }
});