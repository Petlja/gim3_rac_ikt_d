$.i18n().load({
    "en": {
        "nimgame_restart_buttnon": "Restart",
        "nimgame_take": "Take",
        "nimgame_single_player": "Single player",
        "nimgame_error": "You can take up to $1",
        "nimgame_winner" : "Player $1 won.",
        "nimgame_alg_won" : "Computer won."
    }
})