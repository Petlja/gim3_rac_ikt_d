$.i18n().load({
    "sr-Cyrl": {
        "msg_no_answer": "Неодговорено.",
        "msg_fitb_check_me": "Провери"
    }
});