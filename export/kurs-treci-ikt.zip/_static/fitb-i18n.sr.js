$.i18n().load({
    "sr": {
        "msg_no_answer": "Неодговорено.",
        "msg_fitb_check_me": "Провери"
    }
});