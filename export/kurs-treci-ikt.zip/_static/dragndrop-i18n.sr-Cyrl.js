$.i18n().load({
    "sr-Cyrl": {
        "msg_dragndrop_correct_answer": "Тачан одговор!",
        "msg_dragndrop_incorrect_answer": "Нетачно. Добили сте $1 тачних и $2 нетачних од $3. Остало вам је $4 празнина.",
        "msg_dragndrop_check_me": "Провери",
        "msg_dragndrop_reset": "Поништи"
    }
});