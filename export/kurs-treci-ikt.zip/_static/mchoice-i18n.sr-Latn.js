$.i18n().load({
    "sr-Latn": {
        "msg_mchoice_correct_answer": "Tačno!",
        "msg_mchoice_incorrect_answer": "Netačno.",
        "msg_mchoice_check_me": "Proveri"
    }
});