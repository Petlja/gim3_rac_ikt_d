$.i18n().load({
    "en": {
        "msg_parson_check_me": "Check",
        "msg_parson_reset": "Reset",
        "msg_parson_too_short" : "Your solution is too short. Add more blocks.",
        "msg_parson_drag_from_here" : "Drag from here",
        "msg_parson_drag_to_here" : "Drop blocks here"
    }
});