$.i18n().load({
    "sr-Latn": {
        "msg_no_answer": "Neodgovoreno.",
        "msg_fitb_check_me": "Proveri"
    }
});