$.i18n().load({
    "sr-Cyrl": {
        "msg_asc_solve_group": "Реши Колону",
        "msg_asc_solve_final": "Коначно решење",
    }
})