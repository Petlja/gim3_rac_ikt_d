
var $builtinmodule = PygameLib.pygame_module;