$.i18n().load({
    "sr-Cyrl": {
        "msg_karel_crashed": "Робот је ударио у зид!",
        "msg_karel_no_ball": "Не постоји лоптица на пољу!",
        "msg_karel_out_of_bounds": "Робот је ударио у спољни зид!",
        "msg_karel_no_balls_with_robot": "Робот нема лоптица код себе!",
        "msg_karel_incorrect": "Нетачно!",
        "msg_karel_correct": "Тачно!"
    }
})