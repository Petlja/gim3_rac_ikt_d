$.i18n().load({
    "en": {
        "regex_title": "REGULAR EXPRESION",
        "flag_title": "FLAGS",
        "text_title": "TEST STRING",
        "button_text": "SHOW SOLUTION",
        "button_test" : "TEST ANSWER",
        "correct": "Correct",
        "incorrect" : "Wrong",
    }
})