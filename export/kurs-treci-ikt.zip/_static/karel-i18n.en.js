$.i18n().load({
    "en": {
        "msg_karel_crashed": "Robot crashed at the wall!",
        "msg_karel_no_ball": "No balls on the square!",
        "msg_karel_out_of_bounds": "Robot went outside of the grid!",
        "msg_karel_no_balls_with_robot": "No balls with robot!",
        "msg_karel_incorrect": "Incorrect!",
        "msg_karel_correct": "Correct!"
    }
})