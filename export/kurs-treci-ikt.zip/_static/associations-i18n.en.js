$.i18n().load({
    "en": {
        "msg_asc_solve_group": "Solve the group",
        "msg_asc_solve_final": "Solve the association",
    }
})