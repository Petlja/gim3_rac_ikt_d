$.i18n().load({
    "sr-Latn": {
        "regex_title": "Regularni izraz",
        "flag_title": "Opcije",
        "text_title": "Tekst test",
        "button_text": "Prikaži rešenje",
        "button_test" : "Uporedi rešenje",
        "correct": "Tačno",
        "incorrect" : "Netačno",
    }
})