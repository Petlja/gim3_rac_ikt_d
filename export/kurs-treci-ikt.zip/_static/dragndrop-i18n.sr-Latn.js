$.i18n().load({
    "sr-Latn": {
        "msg_dragndrop_correct_answer": "Tačan odgovor!",
        "msg_dragndrop_incorrect_answer": "Netačno. Dobili ste $1 tačnih i $2 netačnih od $3. Ostalo vam je $4 praznina.",
        "msg_dragndrop_check_me": "Proveri",
        "msg_dragndrop_reset": "Poništi"
    }
});