// The Bootstrap-based Sphinx theme uses $jqTheme
// Setting $ is needed to override the (old!) version of jQuery packaged with Sphinx
var $jqTheme = jQuery.noConflict();
var $ = jQuery.noConflict();
