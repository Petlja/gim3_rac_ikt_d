$.i18n().load({
    "sr": {
        "msg_asc_solve_group": "Реши Колону",
        "msg_asc_solve_final": "Коначно решење",
    }
})