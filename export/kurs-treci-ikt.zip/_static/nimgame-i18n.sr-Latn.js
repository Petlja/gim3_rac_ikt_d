$.i18n().load({
    "sr-Latn": {
        "nimgame_restart_buttnon": "Ponovi igru",
        "nimgame_take": "Označi",
        "nimgame_single_player": "Igraj protiv računara",
        "nimgame_error": "Možes označiti najviše $1 kružić",
        "nimgame_winner" : "Igrač $1 je pobedio.",
        "nimgame_alg_won" : "Računar je pobedio."
    }
})