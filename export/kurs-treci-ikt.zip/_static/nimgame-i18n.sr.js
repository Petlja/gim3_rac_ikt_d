$.i18n().load({
    "sr": {
        "nimgame_restart_buttnon": "Понови игру",
        "nimgame_take": "Означи кружић",
        "nimgame_single_player": "Играј против рачунара",
        "nimgame_error": "Можеш означити највише $1 кружић",
        "nimgame_winner" : "Играч $1 је победио.",
        "nimgame_alg_won" : "Рачунар је победио."
    }
})