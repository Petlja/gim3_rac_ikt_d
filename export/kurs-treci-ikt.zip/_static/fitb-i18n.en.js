$.i18n().load({
    "en": {
        "msg_no_answer": "No answer provided.",
        "msg_fitb_check_me": "Check me"
    }
});