$.i18n().load({
    "sr": {
        "msg_mchoice_correct_answer": "Taчно!",
        "msg_mchoice_incorrect_answer": "Нетачно.",
        "msg_mchoice_check_me": "Провери"
    }
});