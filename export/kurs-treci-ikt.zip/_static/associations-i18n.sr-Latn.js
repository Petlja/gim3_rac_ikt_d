$.i18n().load({
    "sr-Latn": {
        "msg_asc_solve_group": "Reši kolonu",
        "msg_asc_solve_final": "Končno rešenje",
    }
})