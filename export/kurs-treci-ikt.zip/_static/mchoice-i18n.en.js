$.i18n().load({
    "en": {
        "msg_mchoice_correct_answer": "Correct.",
        "msg_mchoice_incorrect_answer": "Incorrect. You gave $1 {{PLURAL:$1|answer|answers}} and got $2 correct of $3 needed.",
        "msg_mchoice_check_me": "Check me"
    }
});