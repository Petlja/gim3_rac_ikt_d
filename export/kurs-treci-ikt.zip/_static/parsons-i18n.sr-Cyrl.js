$.i18n().load({
    "sr": {
        "msg_parson_check_me": "Провери",
        "msg_parson_reset": "Поништи",
        "msg_parson_too_short" :  "Искористи све блокове у решењу",
        "msg_parson_drag_from_here" : "Превуци одавде",
        "msg_parson_drag_to_here" : "Превуци овде"
    }
});